package com.example.java2;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        Button botao = findViewById(R.id.btn_cadastrar);

        TextInputLayout nome = findViewById(R.id.etxtNomePet);
        TextInputLayout especie = findViewById(R.id.etxtEspecie);
        TextInputLayout idade = findViewById(R.id.etxtIdadePet);

        botao.setOnClickListener(v -> {

            String textoNome = nome.getEditText().getText().toString();
            String textoEspecie = especie.getEditText().getText().toString();
            String textoIdade = idade.getEditText().getText().toString();

            Log.d("Pet", "Nome: " + textoNome);
            Log.d("Pet", "Espécie: " + textoEspecie);
            Log.d("Pet", "Idade: " + textoIdade);

            Toast.makeText(
                    this,
                    textoNome + " (" + textoEspecie + "), "
                            + textoIdade + " anos, cadastrado com sucesso!",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}