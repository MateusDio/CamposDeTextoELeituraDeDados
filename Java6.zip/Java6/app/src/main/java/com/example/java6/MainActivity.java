package com.example.java6;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            v.setPadding(
                    systemBars.left,
                    systemBars.top,
                    systemBars.right,
                    systemBars.bottom
            );

            return insets;
        });

        EditText etxtProduto = findViewById(R.id.etxtProduto);
        EditText etxtPreco = findViewById(R.id.etxtPreco);
        EditText etxtQuantidade = findViewById(R.id.etxtQuantidade);
        Button btnCadastrar = findViewById(R.id.btn_Cadastrar);
        TextView txtResultado = findViewById(R.id.txtResultado);

        btnCadastrar.setOnClickListener(v -> {

            String produto = etxtProduto.getText().toString().trim();
            String precoStr = etxtPreco.getText().toString().trim();
            String qtdStr = etxtQuantidade.getText().toString().trim();

            try {

                double preco = Double.parseDouble(precoStr);

                if (preco <= 0) {
                    Toast.makeText(
                            this,
                            "Preço inválido!",
                            Toast.LENGTH_SHORT
                    ).show();

                    txtResultado.setText("Preço inválido!");
                    return;
                }

                int quantidade = qtdStr.isEmpty()
                        ? 0
                        : Integer.parseInt(qtdStr);

                double valorEstoque = preco * quantidade;

                Toast.makeText(
                        this,
                        "Produto cadastrado!",
                        Toast.LENGTH_SHORT
                ).show();

                System.out.println("Produto: " + produto);
                System.out.println("Preço: R$ " + precoStr);
                System.out.println("Quantidade: " + quantidade);

                txtResultado.setText(
                        produto + " cadastrado! Valor em estoque: R$ "
                                + valorEstoque
                );

            } catch (NumberFormatException e) {

                Toast.makeText(
                        this,
                        "Preço inválido!",
                        Toast.LENGTH_SHORT
                ).show();

                txtResultado.setText("Preço inválido!");
            }
        });
    }
}