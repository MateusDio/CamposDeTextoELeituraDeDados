package com.example.java5;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText etxtNome = findViewById(R.id.etxtNome);
        EditText etxtEmail = findViewById(R.id.etxtEmail);
        EditText etxtIdade = findViewById(R.id.etxtIdade);
        Button btn_Inscrever = findViewById(R.id.btn_Inscrever);
        TextView txtResultado = findViewById(R.id.txtResultado);

        btn_Inscrever.setOnClickListener(v -> {
            String nome = etxtNome.getText().toString();
            String email = etxtEmail.getText().toString();
            String idadeStr = etxtIdade.getText().toString();

            System.out.println("Nome: " + nome);
            System.out.println("E-mail: " + email);
            System.out.println("Idade: " + idadeStr);

            try {
                int idade = Integer.parseInt(idadeStr);

                if (idade >= 14 && idade <= 99) {
                    System.out.println("Inscrição confirmada!");
                    txtResultado.setText(getString(R.string.inscricao_confirmada, nome));
                } else {
                    System.out.println("Idade inválida para o evento.");
                    txtResultado.setText(getString(R.string.idade_invalida));
                }
            } catch (NumberFormatException e) {
                System.out.println("Idade inválida para o evento.");
                txtResultado.setText(getString(R.string.idade_invalida));
            }
        });
    }
}