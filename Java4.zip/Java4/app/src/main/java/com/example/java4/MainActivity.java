package com.example.java4;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText etxtEmail = findViewById(R.id.etxtEmail);
        EditText etxtSenha = findViewById(R.id.etxtSenha);
        Button btnEntrar = findViewById(R.id.btn_Entrar);
        TextView txtResultado = findViewById(R.id.txtResultado);

        btnEntrar.setOnClickListener(v -> {
            String email = etxtEmail.getText().toString();
            String senha = etxtSenha.getText().toString();

            System.out.println("E-mail digitado: " + email);
            System.out.println("Senha com " + senha.length() + " caracteres");

            Log.d("LOGIN", "E-mail digitado: " + email);
            Log.d("LOGIN", "Senha com " + senha.length() + " caracteres");

            if (senha.length() < 6) {
                String mensagemErro = "Senha muito curta! Mínimo 6 caracteres.";
                System.out.println(mensagemErro);
                Log.d("LOGIN", mensagemErro);
                txtResultado.setText(mensagemErro);
            } else {
                String mensagemSucesso = "Login realizado: " + email;
                String mensagemBoasVindas = "Bem-vindo(a), " + email + "!";
                System.out.println(mensagemSucesso);
                Log.d("LOGIN", mensagemSucesso);
                txtResultado.setText(mensagemBoasVindas);
            }
        });
    }
}