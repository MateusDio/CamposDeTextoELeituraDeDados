package com.example.java1;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button botao = findViewById(R.id.btn_pedir);
        TextInputLayout lanche = findViewById(R.id.etxtLanche);
        TextInputLayout bebida = findViewById(R.id.etxtBebida);
        TextInputLayout observacao = findViewById(R.id.etxtObservacao);


        botao.setOnClickListener(v -> {

            String textoLanche = lanche.getEditText().getText().toString();
            String textoBebida = bebida.getEditText().getText().toString();
            String textoObservacao = observacao.getEditText().getText().toString();

            // Terminal / Logcat
            Log.d("PEDIDO", "Lanche: " + textoLanche);
            Log.d("PEDIDO", "Bebida: " + textoBebida);
            Log.d("PEDIDO", "Observação: " + textoObservacao);

            // Mensagem na tela
            Toast.makeText(this,
                    "Pedido: " + textoLanche + " + " + textoBebida +
                            " (" + textoObservacao + ")",
                    Toast.LENGTH_SHORT).show();
        });

    }

}