package com.example.java7;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etxtEmail;
    private EditText etxtConfirmarEmail;
    private TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etxtEmail = findViewById(R.id.etxtEmail);
        etxtConfirmarEmail = findViewById(R.id.etxtConfirmarEmail);
        txtResultado = findViewById(R.id.txtResultado);

        Button btnRecuperar = findViewById(R.id.btn_Recuperar);
        btnRecuperar.setOnClickListener(v -> recuperarSenha());
    }

    private void recuperarSenha() {
        String email = etxtEmail.getText() != null ? etxtEmail.getText().toString() : "";
        String confirmacao = etxtConfirmarEmail.getText() != null ? etxtConfirmarEmail.getText().toString() : "";

        System.out.println("E-mail: " + email);
        System.out.println("Confirmação: " + confirmacao);

        Log.d("MainActivity", "E-mail: " + email);
        Log.d("MainActivity", "Confirmação: " + confirmacao);

        String mensagem;
        if (email.equals(confirmacao)) {
            mensagem = "Link enviado para " + email;
        } else {
            mensagem = "Os e-mails não conferem!";
        }

        System.out.println(mensagem);
        Log.d("MainActivity", mensagem);

        txtResultado.setText(mensagem);
    }
}