package com.example.java3;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        Button botao = findViewById(R.id.btn_Reservar);

        TextInputLayout nome = findViewById(R.id.etxtNome);
        TextInputLayout horario = findViewById(R.id.etxtHorario);
        TextInputLayout sala = findViewById(R.id.etxtSala);

        botao.setOnClickListener(v -> {

            String textoNome = nome.getEditText().getText().toString();
            String textoHorario = horario.getEditText().getText().toString();
            String textoSala = sala.getEditText().getText().toString();

            Log.d("Aula", "Nome: " + textoNome);
            Log.d("Aula", "Sala: " + textoHorario);
            Log.d("Aula", "Horário: " + textoSala);

            Toast.makeText(
                    this,
                    textoSala + " reservado para " + textoNome + " às "
                            + textoHorario,
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}